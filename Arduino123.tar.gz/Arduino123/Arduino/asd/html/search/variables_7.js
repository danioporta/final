var searchData=
[
  ['light',['light',['../structsensors__event__t.html#adefd2ce2da44e4449ef7cadeaecc6cfd',1,'sensors_event_t']]],
  ['lis',['lis',['../classAdafruit__CircuitPlayground.html#a6b218d8b2469594f3e8b8c92227fbd67',1,'Adafruit_CircuitPlayground']]]
];
