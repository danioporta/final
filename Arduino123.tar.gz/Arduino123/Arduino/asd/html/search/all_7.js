var searchData=
[
  ['imprimirlectura',['imprimirLectura',['../fun_8h.html#af746ea1df7be82e72fdbf5d65a14e1d7',1,'fun.cpp']]],
  ['interruptlock',['InterruptLock',['../classInterruptLock.html',1,'']]],
  ['irdecoder',['irDecoder',['../classAdafruit__CircuitPlayground.html#a01c807cb0fa1314ced163ba5c78fc05e',1,'Adafruit_CircuitPlayground']]],
  ['irreceiver',['irReceiver',['../classAdafruit__CircuitPlayground.html#a22c0f30da92dbf8d930b9f64904b710f',1,'Adafruit_CircuitPlayground']]],
  ['irsend',['irSend',['../classAdafruit__CircuitPlayground.html#a41528eb4f276511fadd61492cfa0ef13',1,'Adafruit_CircuitPlayground']]],
  ['isexpress',['isExpress',['../classAdafruit__CircuitPlayground.html#a1b42d9ecde2c0ed1d030fda3ff97b7c9',1,'Adafruit_CircuitPlayground']]]
];
