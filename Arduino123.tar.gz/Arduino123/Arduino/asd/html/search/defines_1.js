var searchData=
[
  ['bcoefficient',['BCOEFFICIENT',['../Adafruit__Circuit__Playground_8h.html#a4ea9e58bc3ede78b23d4ed2f84f8ef97',1,'Adafruit_Circuit_Playground.h']]]
];
