var searchData=
[
  ['motionx',['motionX',['../classAdafruit__CircuitPlayground.html#a1f1572fe8ad1dea0433a3096d759ce79',1,'Adafruit_CircuitPlayground']]],
  ['motiony',['motionY',['../classAdafruit__CircuitPlayground.html#af93578a067cb8663c12225746e090ea0',1,'Adafruit_CircuitPlayground']]],
  ['motionz',['motionZ',['../classAdafruit__CircuitPlayground.html#a85eaee6e9851b2aa801521a8897d7d53',1,'Adafruit_CircuitPlayground']]]
];
