var searchData=
[
  ['pitch',['pitch',['../structsensors__vec__t.html#aa298c3cbbd0016698c64d9451fbf3aff',1,'sensors_vec_t']]],
  ['pressure',['pressure',['../structsensors__event__t.html#a2ec6e34e1a6cf832d85ca19066bd38f0',1,'sensors_event_t']]]
];
