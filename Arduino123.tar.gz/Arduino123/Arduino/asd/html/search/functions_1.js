var searchData=
[
  ['clearpixels',['clearPixels',['../classAdafruit__CircuitPlayground.html#a5a7dd271d9478c13a0dbcc3addba34c2',1,'Adafruit_CircuitPlayground']]],
  ['colorwheel',['colorWheel',['../classAdafruit__CircuitPlayground.html#a788663b6c0bc5f909a71b6505ccfd3f9',1,'Adafruit_CircuitPlayground']]],
  ['computeheatindex',['computeHeatIndex',['../classDHT.html#a47724a419777972edf68cd5b8aa85569',1,'DHT::computeHeatIndex(bool isFahrenheit=true)'],['../classDHT.html#a0d23921017e3d827e49bfd136b40a6aa',1,'DHT::computeHeatIndex(float temperature, float percentHumidity, bool isFahrenheit=true)']]],
  ['condicion',['condicion',['../fun_8h.html#a4bfcff6cee2782fbb357b5679d093628',1,'fun.cpp']]],
  ['convertctof',['convertCtoF',['../classDHT.html#a582df4d39cd56b4acbd47fbe75aedcc3',1,'DHT']]],
  ['convertftoc',['convertFtoC',['../classDHT.html#a90530e38a2f47893e4767dda1d00d2a4',1,'DHT']]]
];
