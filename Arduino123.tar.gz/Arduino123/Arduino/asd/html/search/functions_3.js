var searchData=
[
  ['gamma8',['gamma8',['../classAdafruit__CircuitPlayground.html#aeb6d798f853da3abae8f7aaa8d048703',1,'Adafruit_CircuitPlayground']]],
  ['getacceltap',['getAccelTap',['../classAdafruit__CircuitPlayground.html#a7d32a281f194e63b0331499cbf4e0945',1,'Adafruit_CircuitPlayground']]],
  ['getevent',['getEvent',['../classDHT__Unified_1_1Temperature.html#adeb63f8a2c39634d005f822db81d4d76',1,'DHT_Unified::Temperature::getEvent()'],['../classDHT__Unified_1_1Humidity.html#a17de7d73587c312e0a2b7ea1dcf35ba8',1,'DHT_Unified::Humidity::getEvent()']]],
  ['getsensor',['getSensor',['../classDHT__Unified_1_1Temperature.html#a2d952e5ed342ce324fca0d2f8854d2d7',1,'DHT_Unified::Temperature::getSensor()'],['../classDHT__Unified_1_1Humidity.html#a424a424cfeabd672c93fffd4c9ad0ff0',1,'DHT_Unified::Humidity::getSensor()']]]
];
