var searchData=
[
  ['sensor_5fid',['sensor_id',['../structsensors__event__t.html#a6b06d35b17afbee79de7f45d9d71ed0b',1,'sensors_event_t::sensor_id()'],['../structsensor__t.html#a224f6201d59873cc1b6e9dd8a1894736',1,'sensor_t::sensor_id()']]],
  ['speaker',['speaker',['../classAdafruit__CircuitPlayground.html#adef3edb490a581e3174dc5ac2459a63d',1,'Adafruit_CircuitPlayground']]],
  ['strip',['strip',['../classAdafruit__CircuitPlayground.html#a760a8742d496a0a916d1c8de650be977',1,'Adafruit_CircuitPlayground']]]
];
