var searchData=
[
  ['version',['version',['../structsensors__event__t.html#a2134d60fdb21e3495c595a2df2f5cece',1,'sensors_event_t::version()'],['../structsensor__t.html#a274f12a47669fbd2b61935706339e1c2',1,'sensor_t::version()']]],
  ['voltage',['voltage',['../structsensors__event__t.html#ab01b52f6b83f390a6370d319ded97b28',1,'sensors_event_t']]]
];
