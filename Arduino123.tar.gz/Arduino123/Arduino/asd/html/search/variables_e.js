var searchData=
[
  ['temperature',['temperature',['../structsensors__event__t.html#a914f76beb75bd99aa3c13d3a8e56e21c',1,'sensors_event_t']]],
  ['timestamp',['timestamp',['../structsensors__event__t.html#acd3be1560458b3e3bf52f93f744e8238',1,'sensors_event_t']]],
  ['type',['type',['../structsensors__event__t.html#a58401dd7f3400d9eb96c71b8fba9f8e8',1,'sensors_event_t::type()'],['../structsensor__t.html#ae1d59df64438923d3bd95f2416c32203',1,'sensor_t::type()']]]
];
