var searchData=
[
  ['r',['r',['../structsensors__color__t.html#acdeed981e7df8c701e09d4b2fdb9a40c',1,'sensors_color_t']]],
  ['read',['read',['../classDHT.html#a4c1508f2997a5d03968b3afdeae70e03',1,'DHT']]],
  ['readcap',['readCap',['../classAdafruit__CircuitPlayground.html#a18cde54564e4ea9956f5c0e65bd1e923',1,'Adafruit_CircuitPlayground']]],
  ['readhumidity',['readHumidity',['../classDHT.html#a5f8c84378abe4eeecf34f09e2cdf90a0',1,'DHT']]],
  ['readtemperature',['readTemperature',['../classDHT.html#a68be09105aa7d831bb473c9d774918cf',1,'DHT']]],
  ['redled',['redLED',['../classAdafruit__CircuitPlayground.html#a63ef98e44c01261d8d46e36b1b307fbc',1,'Adafruit_CircuitPlayground']]],
  ['relative_5fhumidity',['relative_humidity',['../structsensors__event__t.html#a577b73698368fb061382ce9f31052417',1,'sensors_event_t']]],
  ['reserved0',['reserved0',['../structsensors__event__t.html#a8be4dc00344f46abf29e06251bf9fad9',1,'sensors_event_t']]],
  ['resolution',['resolution',['../structsensor__t.html#a926aba3216afd50e62c0a6cdbcc7433a',1,'sensor_t']]],
  ['rgba',['rgba',['../structsensors__color__t.html#a0afbff980c17fbacdab1666735f3d3e6',1,'sensors_color_t']]],
  ['rightbutton',['rightButton',['../classAdafruit__CircuitPlayground.html#ac4427acf94accc841903f0460a921063',1,'Adafruit_CircuitPlayground']]],
  ['roll',['roll',['../structsensors__vec__t.html#a6d8c6e288de54942e1d2be4f42f96bb2',1,'sensors_vec_t']]]
];
