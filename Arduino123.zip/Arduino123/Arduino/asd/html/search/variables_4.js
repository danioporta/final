var searchData=
[
  ['g',['g',['../structsensors__color__t.html#ac91ecea980718cf134f60c497d2a0049',1,'sensors_color_t']]],
  ['gyro',['gyro',['../structsensors__event__t.html#ad108ea8c3a18d02cfc674ba27e94a2c4',1,'sensors_event_t']]]
];
