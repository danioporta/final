var searchData=
[
  ['r',['r',['../structsensors__color__t.html#acdeed981e7df8c701e09d4b2fdb9a40c',1,'sensors_color_t']]],
  ['relative_5fhumidity',['relative_humidity',['../structsensors__event__t.html#a577b73698368fb061382ce9f31052417',1,'sensors_event_t']]],
  ['reserved0',['reserved0',['../structsensors__event__t.html#a8be4dc00344f46abf29e06251bf9fad9',1,'sensors_event_t']]],
  ['resolution',['resolution',['../structsensor__t.html#a926aba3216afd50e62c0a6cdbcc7433a',1,'sensor_t']]],
  ['rgba',['rgba',['../structsensors__color__t.html#a0afbff980c17fbacdab1666735f3d3e6',1,'sensors_color_t']]],
  ['roll',['roll',['../structsensors__vec__t.html#a6d8c6e288de54942e1d2be4f42f96bb2',1,'sensors_vec_t']]]
];
