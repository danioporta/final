var searchData=
[
  ['cap',['cap',['../classAdafruit__CircuitPlayground.html#af1d0c3b099a5ed16515e81675d665aca',1,'Adafruit_CircuitPlayground']]],
  ['circuitplayground',['CircuitPlayground',['../Adafruit__Circuit__Playground_8h.html#a0b940bbd5fe674c94baa3e04ac8849ed',1,'CircuitPlayground():&#160;Adafruit_CircuitPlayground.cpp'],['../Adafruit__CircuitPlayground_8cpp.html#a0b940bbd5fe674c94baa3e04ac8849ed',1,'CircuitPlayground():&#160;Adafruit_CircuitPlayground.cpp']]],
  ['color',['color',['../structsensors__event__t.html#a56b4d05fbf47013727ec1a0a94db91e6',1,'sensors_event_t']]],
  ['current',['current',['../structsensors__event__t.html#ad34303af57d6bce18c34862a887fc005',1,'sensors_event_t']]]
];
