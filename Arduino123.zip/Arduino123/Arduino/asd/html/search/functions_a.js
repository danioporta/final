var searchData=
[
  ['sensecolor',['senseColor',['../classAdafruit__CircuitPlayground.html#a220587e07466040a53396f13415bd5ab',1,'Adafruit_CircuitPlayground::senseColor(uint8_t &amp;red, uint8_t &amp;green, uint8_t &amp;blue)'],['../classAdafruit__CircuitPlayground.html#a98e66e91960fd7c4c28676f8527d548d',1,'Adafruit_CircuitPlayground::senseColor()']]],
  ['setaccelrange',['setAccelRange',['../classAdafruit__CircuitPlayground.html#ad3da16136643f374f36987af46ef5cf7',1,'Adafruit_CircuitPlayground']]],
  ['setacceltap',['setAccelTap',['../classAdafruit__CircuitPlayground.html#a0cd203aff1eaadbd0e7aa7c63556c6b2',1,'Adafruit_CircuitPlayground']]],
  ['setbrightness',['setBrightness',['../classAdafruit__CircuitPlayground.html#a1806b9d22f73edcdd30e28fc9878d29f',1,'Adafruit_CircuitPlayground']]],
  ['setpixelcolor',['setPixelColor',['../classAdafruit__CircuitPlayground.html#aeabcd5c97e80eea7028e49d75ddebdd5',1,'Adafruit_CircuitPlayground::setPixelColor(uint8_t p, uint32_t c)'],['../classAdafruit__CircuitPlayground.html#ab733a86d2fb5435121db18c0cfc747f0',1,'Adafruit_CircuitPlayground::setPixelColor(uint8_t p, uint8_t r, uint8_t g, uint8_t b)']]],
  ['setup',['setup',['../fun_8h.html#a4fc01d736fe50cf5b977f755b675f11d',1,'fun.cpp']]],
  ['sine8',['sine8',['../classAdafruit__CircuitPlayground.html#af9d42a0db0e608a78df856181816451a',1,'Adafruit_CircuitPlayground']]],
  ['slideswitch',['slideSwitch',['../classAdafruit__CircuitPlayground.html#aa65e8d13f9ff704c4c036c7cc89dc132',1,'Adafruit_CircuitPlayground']]],
  ['soundsensor',['soundSensor',['../classAdafruit__CircuitPlayground.html#a400cbdaa9aa0cdd119b94e355e48b043',1,'Adafruit_CircuitPlayground']]]
];
