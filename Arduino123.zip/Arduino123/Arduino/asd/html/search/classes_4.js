var searchData=
[
  ['sensor_5ft',['sensor_t',['../structsensor__t.html',1,'']]],
  ['sensors_5fcolor_5ft',['sensors_color_t',['../structsensors__color__t.html',1,'']]],
  ['sensors_5fevent_5ft',['sensors_event_t',['../structsensors__event__t.html',1,'']]],
  ['sensors_5fvec_5ft',['sensors_vec_t',['../structsensors__vec__t.html',1,'']]],
  ['simpledht',['SimpleDHT',['../classSimpleDHT.html',1,'']]],
  ['simpledht11',['SimpleDHT11',['../classSimpleDHT11.html',1,'']]],
  ['simpledht22',['SimpleDHT22',['../classSimpleDHT22.html',1,'']]]
];
