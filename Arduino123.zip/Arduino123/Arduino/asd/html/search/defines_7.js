var searchData=
[
  ['segdia',['SEGDIA',['../fun_8h.html#a2b5f96276a0ce1e52aade24267bebbe3',1,'fun.h']]],
  ['seghigh',['SEGHIGH',['../fun_8h.html#a5a91e0ee5eaa5088d058385bb9327f7f',1,'fun.h']]],
  ['segsus',['SEGSUS',['../fun_8h.html#a4e46873b9247b7f20181934ac169a174',1,'fun.h']]],
  ['seriesresistor',['SERIESRESISTOR',['../Adafruit__Circuit__Playground_8h.html#aeda514ffe2696b78d945bc12a07b63cf',1,'Adafruit_Circuit_Playground.h']]],
  ['si',['SI',['../fun_8h.html#aa1be7844620ac7bffe73137a180aa044',1,'fun.h']]]
];
