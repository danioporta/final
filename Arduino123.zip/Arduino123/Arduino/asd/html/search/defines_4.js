var searchData=
[
  ['light_5fsettle_5fms',['LIGHT_SETTLE_MS',['../Adafruit__Circuit__Playground_8h.html#ab2b1599b10bc8601ce95e57280550e60',1,'Adafruit_Circuit_Playground.h']]]
];
