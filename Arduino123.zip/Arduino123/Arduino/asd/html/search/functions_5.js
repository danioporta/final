var searchData=
[
  ['imprimirlectura',['imprimirLectura',['../fun_8h.html#af746ea1df7be82e72fdbf5d65a14e1d7',1,'fun.cpp']]],
  ['isexpress',['isExpress',['../classAdafruit__CircuitPlayground.html#a1b42d9ecde2c0ed1d030fda3ff97b7c9',1,'Adafruit_CircuitPlayground']]]
];
