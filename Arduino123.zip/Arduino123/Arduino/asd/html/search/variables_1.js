var searchData=
[
  ['b',['b',['../structsensors__color__t.html#a1bf461b5c728e323f8883a3785c7c60b',1,'sensors_color_t']]]
];
