/**
 * @brief fun.cpp contiene la importación del fichero con lass funciones y variables mediante la inclusión del 
 * fichero fun.h
 * En este archivo se encuentra la lógica de los funciones a utilizar para el sistema de riego
 */
#include "fun.h"

/**
 * @sec setup 
 * Se declaran los PIN (número definido en .h) y el modo OUTPUT que utilizará cada bomba, también el número de 
 * comunicación serial con el cual se trabajará (115200)
 * */

void setup()
{
  //BOMBA1
  dht.begin();
  dht2.begin();
  dht3.begin();
  Serial.begin(115200); //NUMERO DE COMUNICACION SERIAL
 
  //BOMBA1(AGUA)
  pinMode(DHTPIN,OUTPUT); //Para el pin número 1 se utiliza el modo OUTPUT
  
  //BOMBA2(SUTSTRATO1)
  pinMode(DHTPIN2,OUTPUT); //Para el pin número 2 se utiliza el modo OUTPUT

  //BOMBA3(SUSTRATO2)
  pinMode(DHTPIN3,OUTPUT); //Para el pin número 3 se utiliza el modo OUTPUT
  
  //HIGROMETRO  
  Serial.begin(115200);  //VELOCIDAD DE COMUNICACION SERIAL: 115200
}

/**
 * @sec imprimirLectura 
 * Se declara una variable tipo entero llamada porcentaje donde por medio de la funcion de Arduino map se convierten 
 * valores de un rango de 0 a 1023
 * de humedad a porcentajes que van de 0 a 100 de acuerdo con esto
 * Según el parámetro de entrada se determiná si el riego se lleva a cabo
 * */

void imprimirLectura(int *puntero)
{
   
   int porcentaje = map(*puntero, 1023, 0,0, 100);  //entero donde se guarda el porcentaje de rango 0-1023 
   Serial.print("La lectura de humedad es: ");  
   Serial.print(*puntero);  //Impresión de valores de humedad de 0 a 1023
   Serial.print(" de 1023 segun los valores de humedad de la tablatura para dht Arduino"); //
   Serial.println(" ");
   
   Serial.print("El porcentaje de la humedad es del: ");  //Impresión de valores de humedad en porcentajes de 0 a 100
   Serial.print(porcentaje);  
   Serial.print("%");
   Serial.println(" ");
} 
  
/**
 * @sec condicion
 * Condiciones de riego de acuerdo a los valores de humedad recolectados por el sensor
 * */

  
void condicion(int *puntero){   
  
   int condicion;  // Varible tipo número entero
   int *ptr;  // Puntero tipo entero
   ptr=&condicion;  // Asignación del puntero, este está apuntando hacia el espacio de memoria donde se encuentra condicion

 //CONDICIONES PARA EL RIEGO SEGUN LOS VALORES DE HUMEDAD  
 if (*puntero>= 1000) {
  Serial.println("El sensor esta desconectado o fuera del suelo");   
  Serial.println("Se desactivara el sistema de riego");   
  digitalWrite(DHTPIN, LOW);   //Apagado de la bomba1 para agua debido al alto nivel de humedad medido por el sensor
  *ptr=NO;   //Se guarda en el puntero *ptr un NO es decir un 0
}
  else if (*puntero<1000 && *puntero>=600)
 {
  Serial.println("El suelo esta seco");   
  Serial.println("Se iniciara el sistema de riego");   //Activación de la bomba1 para agua debido al bajo nivel de humedad medido por el sensor
  digitalWrite(DHTPIN, HIGH);   //
  delay(SEGHIGH);   //El riego de agua se permite solamente durante 10 segundos

  digitalWrite(DHTPIN, LOW);   //Apagado de la bomba1 concluido este intervalo de tiempo
  *ptr=SI;   //Se guarda en el puntero un SI es decir un 1
 }
 else if(*puntero <600 && *puntero >= 370)
 {
  Serial.println("El suelo esta humedo");   
  Serial.println("El sistema de riego se desactivara");   
  digitalWrite(DHTPIN, LOW);   //Apagado de la bomba1 para agua debido al alto nivel de humedad medido por el sensor

  *ptr=SI;   ////Se guarda en el puntero un SI es decir un 1
  }
 else if (*puntero <370)
 {
  Serial.println("El sensor esta sumergido en agua");
  Serial.println("El sistema de riego se desactivara");
  digitalWrite(DHTPIN, LOW);   //Apagado de la bomba1 para agua debido al alto nivel de humedad medido por el sensor
  *ptr=NO;   //Se guarda en el puntero *ptr un NO es decir un 0
  }

  //CONDICION PARA EL RIEGO DE SUSTRATOS SEGUN LOS VALORES DE HUMEDAD 
  if(*ptr=SI) //Si el valor en la condicion es SI(1)
  {
    digitalWrite(DHTPIN2, HIGH);   //BOMBA2 SE ENCIENDE
    digitalWrite(DHTPIN3, HIGH);   //BOMBA3 SE ENCIENDE
    delay(SEGSUS);   //PAUSA DE 5 SEGUNDOS
    digitalWrite(DHTPIN2, LOW);   //BOMBA2 SE APAGA LUEGO DE 5 SEGUNDOS
    digitalWrite(DHTPIN3, LOW);   //BOMBA1 SE APAGA LUEGO DE 5 SEGUNDOS
    Serial.println("Se activara el riego diario de los dos sustratos");   //
    }
  else if(condicion=NO) //Si el valor en la condicion es NO(0)
  {
    digitalWrite(DHTPIN2, LOW);   //BOMBA2 SE APAGA
    digitalWrite(DHTPIN3, LOW);   //BOMBA1 SE APAGA
     Serial.println("No se activara el riego diario de los dos sustratos");
    }
  
  
  
  
 
}

void loop()
{ 
  int lectura = analogRead(A0);   //VALOR DE LECTURA DE LA HUMEDAD DETERMINADO POR EL SENSOR
  int *puntero=&lectura;   // PUNTERO TIPO ENTERO QUE APUNTA AL ESPACIO DE MEMORIA DE ENTERO LECTURA

  imprimirLectura(puntero);   //LLAMADO A FUNCION IMPRIMIR LECTURA
  condicion(puntero);   // LLAMADO A FUNCION CONDICION

  delay(SEGDIA);   //el sistema de riego se ejecuta una vez al dia
  }
