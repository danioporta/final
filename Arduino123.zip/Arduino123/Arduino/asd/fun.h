/**
 * @file fun.h contiene la declaración de funciones y variables constantes así como la inclusión al archivo 
 * de las librerías de Arduino
 * */

#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <DHT.h>
#include <stdio.h>
#include <stdbool.h>
#include <Arduino.h>

#define DHTPIN 9	///< Asignacion de nombre para el PIN 9 como constante
#define DHTTYPE DHT11 ///< Asignacion del tipo de Dispositivo DHT como constante
#define DHTPIN2 10 ///< Asignacion de nombre para el PIN 10 como constante
#define DHTPIN3 11 ///< Asignacion de nombre para el PIN 11 como constante

#define SI 1  ///< Asignacion de nombre para valor 1 
#define NO 0  ///< Asignacion de nombre para valor 0 

#define SEGDIA 86400000 ///< Asignacion de nombre para los milisegundos que contiene 1 dia 
#define SEGHIGH 10000 ///< Asignacion de nombre para los milisegundos contenidos en 10 segundos
#define SEGSUS 5000  ///< Asignacion de nombre para los milisegundos contenidos en 5 segundos

DHT dht(DHTPIN,DHTTYPE);
DHT dht2(DHTPIN2,DHTTYPE);
DHT dht3(DHTPIN3,DHTTYPE);


/**
 * @brief setup Primera función a ejecutarse en la sintaxis un programa en Arduino. Es, básicamente, donde
 * se escriben las funciones que llevará a cabo el microcontrolador, escritas en el cuerpo de la función entre las
 * llaves o
 * corchetes. Seguidamente la función void loop que se utilizará como un bucle o ciclo que se repite infinitamente 
 * hasta
 * que el microcontrolador sea apagado o reiniciado, sujeto a las condiciones y estructuración de código de acuerdo a
 * lo que se necesita para el programa.
 * 
 * 
 * @return no retorna
 * */
void setup();

/**
 * @brief loop Funciona como un bucle o ciclo que se repite infinitamente hasta 
 * que el microcontrolador sea apagado o reiniciado, sujeto a las condiciones y estructuración de código de acuerdo a
 * lo que se necesita para el programa.
 * 
 * 
 * 
 * @return no retorna
 * */

void loop();

/**
 * @brief condicion Funciona con condicionales para manejar el flujo de programa, de modo que de acuerdo a los
 * valores de humedad que entren por parametro
 * a la función se determine si se debe o no regar a las plantas, así como determinar si se debe añadir el sustrato
 * diario a estas
 * @param *puntero Un puntero tipo entero con el valor de AnalogRead en el pin A0, es decir la lectura de humedad
 * según el dispositivo DHT.
 * @return no retorna
 * */
void condicion(int *puntero);

/**
 * @brief imprimirLectura Imprime los valores de humedad del suelo en un margen de 0 a 1023 según la tabla de humedades de DHT para Arduino.
 * Imprime el porcentaje de humedad haciendo uso de la función map de Arduino.
 * @param *puntero Un puntero tipo entero con el valor de AnalogRead en el pin A0, es decir la lectura de humedad según el dispositivo DHT.
 * @return no retorna
 * */
void imprimirLectura(int *puntero);
